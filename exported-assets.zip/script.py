import json

time_slots = [
    "09:30-10:30 AM",
    "10:30-11:30 AM", 
    "11:30-12:30 PM",
    "12:30-02:30 PM",
    "02:30-3:30 PM",
    "03:30-04:30 PM"
]

days = ["MON", "TUE", "WED", "THU", "FRI"]

courses = [
    "MCA-1-A", "MCA-1-B", "MCA-1-C", "MCA-1-D",
    "M.Sc.-1", "BCA-1", "B.Sc.-1"
]

schedule_data = {
    "MON": {
        "MCA-1-A": ["COA (LT-101)", "PDS (LT-101)", "DBMS (LT-101)", "", "", ""],
        "MCA-1-B": ["DM (LT-102)", "COA (LT-102)", "PDS (LT-102)", "", "", ""],
        "MCA-1-C": ["PDS (LT-103)", "DM (LT-103)", "COA (LT-103)", "", "", ""],
        "MCA-1-D": ["COA (LT-101)", "", "", "", "", ""],
        "M.Sc.-1": ["TC (LT-102)", "", "", "", "", ""],
        "BCA-1": ["CP (LT-105)", "FA (LT-105)", "STAT (LT-105)", "", "", ""],
        "B.Sc.-1": ["ES (LT-106)", "STAT (LT-106)", "EL (LT-106)", "", "", ""]
    },
    "TUE": {
        "MCA-1-A": ["SS LAB (LT-101)", "PDS (LT-101)", "COA (LT-101)", "", "", ""],
        "MCA-1-B": ["DBMS (LT-102)", "COA (LT-102)", "OS (LT-102)", "", "", ""],
        "MCA-1-C": ["COA (LT-103)", "OS (LT-103)", "DBMS (LT-103)", "", "", ""],
        "MCA-1-D": ["COA (LT-104)", "", "", "", "PDS LAB (Lab-001)", "DBMS LAB (Lab-103)"],
        "M.Sc.-1": ["TC (LT-005)", "", "", "", "", ""],
        "BCA-1": ["BAS. IT (LT-105)", "", "", "", "", ""],
        "B.Sc.-1": ["CP (LT-106)", "", "", "", "", ""]
    },
    "WED": {
        "MCA-1-A": ["DBMS (LT-101)", "DM (LT-101)", "OS (LT-101)", "", "", ""],
        "MCA-1-B": ["SS LAB (LT-102)", "PDS (LT-102)", "DBMS (LT-102)", "", "", ""],
        "MCA-1-C": ["PDS (LT-103)", "DM (LT-103)", "OS (LT-103)", "", "", ""],
        "MCA-1-D": ["", "", "", "", "DBMS LAB (Lab-103)", "SS LAB (LT-104)"],
        "M.Sc.-1": ["", "", "", "", "", ""],
        "BCA-1": ["STAT (LT-105)", "BAS. IT (LT-105)", "FA (LT-105)", "", "EL (LT-105)", ""],
        "B.Sc.-1": ["WAD (LT-106)", "STAT (LT-106)", "ES (LT-106)", "", "CP (LT-106)", ""]
    },
    "THU": {
        "MCA-1-A": ["OS (LT-101)", "PDS (LT-101)", "YOGA", "COA (LT-101)", "DM (LT-101)", ""],
        "MCA-1-B": ["COA (LT-102)", "PDS (LT-102)", "YOGA", "DM (LT-102)", "OS (LT-102)", ""],
        "MCA-1-C": ["DBMS (LT-103)", "COA (LT-103)", "", "SS LAB (LT-103)", "", ""],
        "MCA-1-D": ["PDS (LT-104)", "DBMS (LT-104)", "YOGA", "DM (LT-104)", "OS (LT-104)", "Placement Prep (Lab-004)"],
        "M.Sc.-1": ["", "", "", "", "", ""],
        "BCA-1": ["BAS. IT (LT-105)", "FA (LT-105)", "", "CP (LT-105)", "CP LAB (Lab-004)", ""],
        "B.Sc.-1": ["WAD (LT-106)", "ES (LT-106)", "", "EL (LT-106)", "STAT LAB (Lab-103)", "WAD LAB (Lab-004)"]
    },
    "FRI": {
        "MCA-1-A": ["DBMS (LT-101)", "DM (LT-101)", "OS (LT-101)", "", "", ""],
        "MCA-1-B": ["DM (LT-102)", "OS (LT-102)", "DBMS (LT-102)", "", "", ""],
        "MCA-1-C": ["OS (LT-103)", "PDS (LT-103)", "YOGA", "DBMS (LT-103)", "DM (LT-103)", ""],
        "MCA-1-D": ["COA (LT-104)", "PDS (LT-104)", "", "DBMS (LT-104)", "PDS LAB (Lab-103)", "PDS LAB (Lab-104)"],
        "M.Sc.-1": ["TC (LT-005)", "", "", "", "", ""],
        "BCA-1": ["CP (LT-105)", "STAT (LT-105)", "", "EL (LT-105)", "STAT LAB (Lab-001)", ""],
        "B.Sc.-1": ["STAT (LT-106)", "EL (LT-106)", "", "CP (LT-106)", "WAD LAB (Lab-002)", "Placement Prep (Lab-004)"]
    }
}

course_names = {
    "MCA-1-A": "Master of Computer Applications - Section A",
    "MCA-1-B": "Master of Computer Applications - Section B", 
    "MCA-1-C": "Master of Computer Applications - Section C",
    "MCA-1-D": "Master of Computer Applications - Section D",
    "M.Sc.-1": "Master of Science - 1st Semester",
    "BCA-1": "Bachelor of Computer Applications - 1st Semester", 
    "B.Sc.-1": "Bachelor of Science - 1st Semester"
}

subject_names = {
    "COA": "Computer Organization & Architecture",
    "PDS": "Programming and Data Structures", 
    "DBMS": "Database Management System",
    "DM": "Discrete Mathematics",
    "OS": "Operating System",
    "TC": "Theory of Computation",
    "CP": "Computer Programming",
    "FA": "Financial Accounting",
    "STAT": "Statistics",
    "ES": "Environmental Science",
    "EL": "English Language",
    "BAS. IT": "Basic Information Technology",
    "WAD": "Web Application Development",
    "SS LAB": "System Software Lab",
    "YOGA": "Yoga",
    "PDS LAB": "Programming and Data Structures Lab",
    "DBMS LAB": "Database Management System Lab",
    "CP LAB": "Computer Programming Lab", 
    "STAT LAB": "Statistics Lab",
    "WAD LAB": "Web Application Development Lab",
    "Placement Prep": "Placement Preparation"
}

data = {
    "timeSlots": time_slots,
    "days": days,
    "courses": courses,
    "schedule": schedule_data,
    "courseNames": course_names,
    "subjectNames": subject_names
}
with open('timetable_data.json', 'w') as f:
    json.dump(data, f, indent=2)
print('Timetable JSON recreated.')